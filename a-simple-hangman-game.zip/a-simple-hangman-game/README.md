# A simple Hangman-game

A Pen created on CodePen.io. Original URL: [https://codepen.io/offline_blogger/pen/MWbmGQ](https://codepen.io/offline_blogger/pen/MWbmGQ).

A simple game in which the user guesses the letters in a word